import tkinter as tk
from tkinter import messagebox
from task import Task
from linked_list import LinkedList
from hash_table import HashTable
from bst import BST

class TodoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("To-Do List Manager")
        self.linked_list = LinkedList()
        self.hash_table = HashTable()
        self.bst = BST()
        self.label = tk.Label(root, text="Task Description:")
        self.label.pack()
        self.task_entry = tk.Entry(root)
        self.task_entry.pack()
        self.priority_label = tk.Label(root, text="Priority (High, Medium, Low):")
        self.priority_label.pack()
        self.priority_entry = tk.Entry(root)
        self.priority_entry.pack()
        self.add_button = tk.Button(root, text="Add Task", command=self.add_task)
        self.add_button.pack()
        self.display_button = tk.Button(root, text="Display Tasks", command=self.display_tasks)
        self.display_button.pack()
        self.search_label = tk.Label(root, text="Search Task:")
        self.search_label.pack()
        self.search_entry = tk.Entry(root)
        self.search_entry.pack()
        self.search_button = tk.Button(root, text="Search", command=self.search_task)
        self.search_button.pack()
        self.tasks_listbox = tk.Listbox(root, width=50, height=10)
        self.tasks_listbox.pack()

    def add_task(self):
        description = self.task_entry.get()
        priority = self.priority_entry.get()
        if description and priority:
            task = Task(description, priority)
            self.linked_list.add_task(task)
            self.hash_table.add_task(task)
            self.bst.insert(task)
            messagebox.showinfo("Success", "Task added successfully!")
            self.task_entry.delete(0, tk.END)
            self.priority_entry.delete(0, tk.END)
        else:
            messagebox.showerror("Error", "Please enter valid details")

    def display_tasks(self):
        self.tasks_listbox.delete(0, tk.END)
        tasks = self.linked_list.display_tasks()
        for task in tasks:
            self.tasks_listbox.insert(tk.END, task)

    def search_task(self):
        description = self.search_entry.get()
        task = self.hash_table.search_task(description)
        if task:
            messagebox.showinfo("Task Found", str(task))
        else:
            messagebox.showerror("Error", "Task not found")

if __name__ == "__main__":
    root = tk.Tk()
    app = TodoApp(root)
    root.mainloop()
