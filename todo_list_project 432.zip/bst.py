class BSTNode:
    def __init__(self, task):
        self.task = task
        self.left = None
        self.right = None

class BST:
    def __init__(self):
        self.root = None

    def insert(self, task):
        if not self.root:
            self.root = BSTNode(task)
        else:
            self._insert(self.root, task)

    def _insert(self, node, task):
        if task.priority > node.task.priority:
            if node.right:
                self._insert(node.right, task)
            else:
                node.right = BSTNode(task)
        else:
            if node.left:
                self._insert(node.left, task)
            else:
                node.left = BSTNode(task)

    def inorder_traversal(self, node=None, tasks=None):
        if tasks is None:
            tasks = []
        if node is None:
            node = self.root
        if node:
            self.inorder_traversal(node.left, tasks)
            tasks.append(node.task)
            self.inorder_traversal(node.right, tasks)
        return tasks
