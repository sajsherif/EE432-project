class Task:
    def __init__(self, description, priority, status=False):
        self.description = description
        self.priority = priority
        self.status = status

    def __str__(self):
        status_str = "✔ Done" if self.status else "❌ Not Done"
        return f"[{self.priority}] {self.description} - {status_str}"
