class Node:
    def __init__(self, task):
        self.task = task
        self.next = None

class LinkedList:
    def __init__(self):
        self.head = None

    def add_task(self, task):
        new_node = Node(task)
        if not self.head:
            self.head = new_node
        else:
            current = self.head
            while current.next:
                current = current.next
            current.next = new_node

    def delete_task(self, description):
        current = self.head
        prev = None
        while current:
            if current.task.description == description:
                if prev:
                    prev.next = current.next
                else:
                    self.head = current.next
                return True
            prev = current
            current = current.next
        return False

    def display_tasks(self):
        tasks = []
        current = self.head
        while current:
            tasks.append(str(current.task))
            current = current.next
        return tasks
