class HashTable:
    def __init__(self, size=100):
        self.size = size
        self.table = [[] for _ in range(size)]

    def _hash(self, key):
        return hash(key) % self.size

    def add_task(self, task):
        index = self._hash(task.description)
        self.table[index].append(task)

    def search_task(self, description):
        index = self._hash(description)
        for task in self.table[index]:
            if task.description == description:
                return task
        return None
