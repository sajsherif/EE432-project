# To-Do List Manager - Python Application

## Introduction
This is a simple To-Do List Manager application built using Python. It allows users to add, delete, search, and display tasks with priority levels. The application is implemented using essential data structures: **Linked List, Hash Table, and Binary Search Tree (BST)**. The graphical user interface (GUI) is built using **Tkinter**.

## Features
- **Add Tasks**: Users can add tasks with a description and priority level (High, Medium, Low).
- **Delete Tasks**: Users can remove tasks from the list.
- **Search Tasks**: Users can search for tasks by description.
- **Display Tasks**: All tasks are displayed in an organized manner.
- **Manage Tasks by Priority**: Tasks are stored and managed using a **Binary Search Tree (BST)** based on priority.

## Installation & Setup
### Prerequisites
Ensure you have Python installed on your system. You can check by running:
```sh
python --version
```
If Python is not installed, download and install it from [Python Official Website](https://www.python.org/downloads/).

### Installing Required Libraries
The application uses **Tkinter**, which is included by default in Python. No extra libraries are needed.

### Running the Application
1. **Download the project files**
   - Extract the `todo_list_project.zip` file.

2. **Navigate to the project folder**
   ```sh
   cd path/to/todo_list_project
   ```

3. **Run the application**
   ```sh
   python todo_app.py
   ```

## How to Use
1. **Adding a Task**
   - Enter the task description in the text field.
   - Specify the priority level (`High`, `Medium`, `Low`).
   - Click the **Add Task** button.
   - The task will be added and stored using linked lists and hash tables.

2. **Displaying All Tasks**
   - Click the **Display Tasks** button.
   - A list of tasks will be shown in the application interface.

3. **Searching for a Task**
   - Enter the task description in the search field.
   - Click the **Search** button.
   - A popup will show whether the task is found or not.

4. **Deleting a Task**
   - Not implemented in the GUI yet, but can be added in the future.

## File Structure
```
📁 todo_list_project
│── task.py            # Task class definition
│── linked_list.py      # Linked List implementation
│── hash_table.py      # Hash Table implementation
│── bst.py             # Binary Search Tree implementation
│── todo_app.py        # Main GUI application
```

## Future Improvements
- Implement delete functionality in the GUI.
- Enhance task sorting using different criteria.
- Store tasks persistently using a database or file.

## Author
Developed for the **EE432 Data Structures Assignment**. 

## License
This project is free to use for educational purposes.
